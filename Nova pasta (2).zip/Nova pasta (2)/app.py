import streamlit as st
import joblib
import re
import string
import nltk

from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

# configurar
st.set_page_config(page_title="Análise Médica", layout="centered")
st.title("Análise de Comentários Médicos")

# modelos
tfidf = joblib.load("tfidf_vectorizer.pkl")
modelo = joblib.load("linear_svc_model.pkl")


stop_words = set(stopwords.words("english"))
lemmatizer = WordNetLemmatizer()

def preprocess_text(texto):
    texto = texto.lower()
    texto = re.sub(f"[{string.punctuation}]", "", texto)
    tokens = texto.split()
    tokens = [t for t in tokens if t not in stop_words]
    tokens = [lemmatizer.lemmatize(t) for t in tokens]
    return " ".join(tokens)


def prever_categoria(texto):
    texto_proc = preprocess_text(texto)
    vetor = tfidf.transform([texto_proc])
    return modelo.predict(vetor)[0]


#sentimento(PLN)

analisador = SentimentIntensityAnalyzer()

def prever_sentimento(texto):
    score = analisador.polarity_scores(texto)["compound"]
    if score >= 0.05:
        return "Positivo"
    elif score <= -0.05:
        return "Negativo"
    else:
        return "Neutro"


categoria_para_especialidade = {
    "Knee pain": "Ortopedia",
    "Joint pain": "Ortopedia",
    "Eye Infection": "Oftalmologia",
    "Skin issue": "Dermatologia",
    "Stomach ache": "Gastroenterologia",
    "Heart hurts": "Cardiologia",
    "Hard to breath": "Pneumologia",
    "Open wound": "Cirurgia Geral"
}


comentario = st.text_area(
    "Digite o comentário do paciente:",
    height=120
)

if st.button("Analisar"):
    if comentario.strip() == "":
        st.warning("Digite um comentário.")
    else:
        categoria = prever_categoria(comentario)
        especialidade = categoria_para_especialidade.get(
            categoria, "Clínica Geral"
        )
        sentimento = prever_sentimento(comentario)

        st.subheader("Resultado")
        st.write(f"**Categoria médica:** {categoria}")
        st.write(f"**Especialidade:** {especialidade}")
        st.write(f"**Sentimento:** {sentimento}")
